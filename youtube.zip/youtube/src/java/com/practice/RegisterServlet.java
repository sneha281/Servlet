package com.practice;
import java.io.IOException;
import java.io.PrintWriter;
import javax.servlet.*;
import javax.servlet.http.*;
import java.util.HashSet;
import java.util.Set;
import java.sql.*;
/**
 *
 * @author sneha
 */
public class RegisterServlet extends HttpServlet{

    
    protected void doGet(HttpServletRequest req, HttpServletResponse res) throws ServletException, IOException{
    
    PrintWriter out = res.getWriter();
    Connection con = null;
    Statement stmt = null;
    String n = "", p="",q="",r="",s="";
    n = req.getParameter("user_name");
    p = req.getParameter("user_age");
    q = req.getParameter("user_gender");
    r=req.getParameter("user_email");
    s=req.getParameter("user_dep");
    try {                        
        Class.forName("com.mysql.jdbc.Driver");
        con = DriverManager.getConnection("jdbc:mysql://localhost:3306/novelvox" , "root" , "sneha2002");
        stmt = con.createStatement();
        stmt.executeUpdate("INSERT INTO novel_vox VALUES('" + n + "','" + p + "','" + q + "','" + r + "','" + s + "')");

        out.println("<h1> Your data saved!!</h1>");
           
    }
    catch(Exception e) {
        out.println("Please use different email ID");
    }  }}

